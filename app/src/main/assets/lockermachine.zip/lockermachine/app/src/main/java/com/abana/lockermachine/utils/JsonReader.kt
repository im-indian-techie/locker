package com.abana.lockermachine.utils

import android.content.Context
import com.google.gson.Gson
import com.google.gson.JsonObject
import java.io.BufferedReader
import java.io.InputStreamReader


class JsonReader {
    fun getJsonObjectFromAssets(context:Context,filename:String): JsonObject? {
        var jsonObject:JsonObject?=null
        try {
            val inputStream= context.assets.open(filename)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonStringBuilder = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                jsonStringBuilder.append(line)
            }
            inputStream.close()
            jsonObject= Gson().fromJson(jsonStringBuilder.toString(),JsonObject::class.java)

        }
        catch (ae:Exception)
        {

        }
        return jsonObject
    }
}