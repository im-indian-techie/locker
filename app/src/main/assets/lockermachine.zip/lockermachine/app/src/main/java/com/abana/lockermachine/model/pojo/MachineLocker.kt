package com.abana.lockermachine.model.pojo

class MachineLocker (
    var machineID:Int,
    var machineName:String,
    var lockerNo:Int ,
    var active:Boolean,
    var lockerSequenceNo:Int,
    var columnSequence:Int,
    var size:Int,
    var modelName:String,
    var id:Int

)