package com.abana.lockermachine.view.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.abana.lockermachine.R
import com.abana.lockermachine.databinding.ActivityMainBinding
import com.abana.lockermachine.viewmodel.HomeViewModel
import dagger.hilt.EntryPoint
import androidx.activity.v

@EntryPoint
class MainActivity : AppCompatActivity() {
    private val activity=this
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initUi()
    }

    private fun initUi() {

    }
}