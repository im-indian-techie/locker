package com.abana.lockermachine.model.pojo

class Result(
    var totalCount:Int,
    var items:MutableList<MachineLocker>,
    var targetUrl:String,
    var success:Boolean,
    var error:Any,
    var unAuthorizedRequest: Boolean,
    var __abp:String
)