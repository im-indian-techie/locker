package com.abana.lockermachine.model.repository

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.abana.lockermachine.model.pojo.MachineLocker
import com.abana.lockermachine.model.pojo.Result
import com.abana.lockermachine.utils.JsonReader
import com.google.gson.Gson

class HomeRepository {
   var jsonData:MutableLiveData<MutableList<MachineLocker>> = MutableLiveData()
   var progressData:MutableLiveData<Boolean> = MutableLiveData()

   fun getJsonData():MutableLiveData<MutableList<MachineLocker>>
   {
      return jsonData;
   }
   fun getProgressData():MutableLiveData<Boolean>
   {
      return progressData
   }

   fun getJsonDataFromResult(context: Context,filename:String)
   {
      progressData.value=true
      val list:MutableList<MachineLocker> = mutableListOf()
      val result=Gson().fromJson(JsonReader().getJsonObjectFromAssets(context,filename).toString(),Result::class.java)
      list.addAll(result.items)
      jsonData.value=list
   }
}